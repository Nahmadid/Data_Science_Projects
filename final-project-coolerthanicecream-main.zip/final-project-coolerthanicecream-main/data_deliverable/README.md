Where to find the submission files:
1. Data spec is found at `/reports/data_spec/README.md`
2. Full downloadable data is found in `/data`
3. Sample of the data (100 rows) is found in `/sample_data`
4. Tech report is found at `reports/tech_report/README.md`
