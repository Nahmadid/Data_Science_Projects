# Presentation
We uploaded our recorded presetation video on youtube.
[Click here for the video](https://youtu.be/6pdXso0WR9k)
